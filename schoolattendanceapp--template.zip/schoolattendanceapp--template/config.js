import firebase from "firebase"

var firebaseConfig = {
  apiKey: "AIzaSyAHn27LO7biwflR31CT614GHoWsu8Z4UvU",
  authDomain: "school-attendence-app-eb0a2.firebaseapp.com",
  databaseURL: "https://school-attendence-app-eb0a2-default-rtdb.firebaseio.com",
  projectId: "school-attendence-app-eb0a2",
  storageBucket: "school-attendence-app-eb0a2.appspot.com",
  messagingSenderId: "139964987464",
  appId: "1:139964987464:web:2107a9ab555bed0df0407d"
};
firebase.initializeApp(firebaseConfig);

  export default firebase.database()
 

  